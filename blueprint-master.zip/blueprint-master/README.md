# [Blueprint Github Pages](http://blueprintjs.com/)

This branch contains the built assets for Blueprint's static landing page and documentation site.

To make contributions and see the source code, go to the [repository's default branch](https://github.com/palantir/blueprint).
